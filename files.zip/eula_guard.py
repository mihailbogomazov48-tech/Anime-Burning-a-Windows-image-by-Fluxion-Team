#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════╗
║         AnimeFlash — EULA & Anti-Piracy Guard            ║
║              🌸 Fluxion Team © 2025 🌸                   ║
╚══════════════════════════════════════════════════════════╝

Модуль: Лицензионное соглашение + защита от пираток
"""

import tkinter as tk
from tkinter import messagebox
import hashlib
import hmac
import os
import sys
import json
import time
import platform
import urllib.request
import threading

# ──────────────────────────────────────────────────────────────
#  КОНФИГ ЗАЩИТЫ
# ──────────────────────────────────────────────────────────────

# Официальный сайт — ТОЛЬКО отсюда можно скачать
OFFICIAL_SITE       = "https://fluxionteam.ru"
OFFICIAL_SITE_ALT   = "https://fluxionteam.github.io"

# URL для онлайн-верификации лицензии (заглушка, замените на реальный)
VERIFY_URL          = "https://fluxionteam.ru/api/verify"

# Секретный HMAC-ключ (встроен в .exe через PyInstaller --key или шифруется)
# В реальной сборке этот ключ заменяется на реальный при билде!
_SECRET_KEY         = b"FLUXION_TEAM_SECRET_2025_ANIMEFLASH"

# Файл где хранится согласие пользователя
EULA_ACCEPTED_FILE  = os.path.join(os.path.expanduser("~"),
                                   ".animeflash", "eula_accepted.json")

# Версия EULA — если изменится, снова покажем соглашение
EULA_VERSION        = "1.0"

# ──────────────────────────────────────────────────────────────
#  ЦВЕТА (одинаковые с main)
# ──────────────────────────────────────────────────────────────
C = {
    "bg":      "#0d0d1a",
    "bg2":     "#12122a",
    "card":    "#1a1a35",
    "accent":  "#ff6eb4",
    "accent2": "#a78bfa",
    "accent3": "#38bdf8",
    "success": "#4ade80",
    "danger":  "#f87171",
    "warning": "#fbbf24",
    "text":    "#f0e6ff",
    "text2":   "#a0a0c0",
    "border":  "#2d2d5e",
}

# ──────────────────────────────────────────────────────────────
#  ТЕКСТ EULA
# ──────────────────────────────────────────────────────────────
EULA_TEXT = """
╔══════════════════════════════════════════════════════════════════╗
║     ЛИЦЕНЗИОННОЕ СОГЛАШЕНИЕ КОНЕЧНОГО ПОЛЬЗОВАТЕЛЯ (EULA)       ║
║              AnimeFlash v1.0 — Fluxion Team                     ║
╚══════════════════════════════════════════════════════════════════╝

Дата: 2025 г.   Правообладатель: Fluxion Team

Внимательно прочитайте данное соглашение перед использованием
программного обеспечения AnimeFlash («Программа»).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. ПРЕДМЕТ СОГЛАШЕНИЯ
   Fluxion Team предоставляет вам ограниченную, неисключительную,
   непередаваемую лицензию на использование Программы исключительно
   для личных, некоммерческих целей.

2. УСЛОВИЯ ИСПОЛЬЗОВАНИЯ
   ✅ Разрешено:
      • Использовать Программу на личных устройствах
      • Создавать резервные копии для личного использования
      • Использовать в некоммерческих и образовательных целях

   ❌ Запрещено:
      • Распространять, продавать или передавать третьим лицам
      • Декомпилировать, дизассемблировать или реверс-инжинирить
      • Удалять или изменять авторские знаки Fluxion Team
      • Использовать в коммерческих целях без письменного разрешения
      • Загружать на торрент-трекеры, файлообменники, варезники

3. ОФИЦИАЛЬНЫЙ ИСТОЧНИК
   Программа распространяется ИСКЛЮЧИТЕЛЬНО через официальные каналы:
   🌐 Сайт: https://fluxionteam.ru
   🐙 GitHub: https://fluxionteam.github.io

   Копии, полученные из других источников (торренты, Telegram-каналы
   без верификации, варезные сайты) могут содержать вредоносный код.
   Fluxion Team не несёт ответственности за ущерб от неофициальных копий.

4. ЗАЩИТА ПРОГРАММЫ
   Программа содержит технические средства защиты (ТСЗ). Обход ТСЗ
   является нарушением законодательства об авторском праве.

5. ПЕРСОНАЛЬНЫЕ ДАННЫЕ
   Программа не собирает, не хранит и не передаёт персональные данные
   пользователей. При проверке подлинности используется только
   анонимный хеш устройства.

6. ОТВЕТСТВЕННОСТЬ
   Программа предоставляется «как есть» (AS IS). Fluxion Team не несёт
   ответственности за прямой или косвенный ущерб, вызванный
   использованием или невозможностью использования Программы.

7. ОБНОВЛЕНИЯ
   Fluxion Team вправе выпускать обновления. Использование обновлений
   регулируется актуальной версией EULA.

8. КОНТАКТ
   По вопросам лицензирования: fluxionteam@proton.me
   Официальный сайт: https://fluxionteam.ru

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Нажимая «Принять», вы подтверждаете, что прочитали, поняли и
согласны с условиями данного соглашения.

                  🌸 Fluxion Team — 2025 🌸
"""

# ──────────────────────────────────────────────────────────────
#  ПРОВЕРКА ПОДЛИННОСТИ ФАЙЛА
# ──────────────────────────────────────────────────────────────

def _get_exe_path() -> str:
    """Путь к запущенному .exe / .py"""
    if getattr(sys, "frozen", False):
        return sys.executable          # PyInstaller .exe
    return os.path.abspath(__file__)   # разработка

def _compute_file_hmac(filepath: str) -> str:
    """HMAC-SHA256 файла — уникальная подпись от Fluxion Team"""
    h = hmac.new(_SECRET_KEY, digestmod=hashlib.sha256)
    try:
        with open(filepath, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
    except Exception:
        return ""
    return h.hexdigest()

def _get_embedded_hmac() -> str:
    """
    В официальной сборке PyInstaller прячет сюда правильный хеш.
    При билде скрипт build.py вычисляет HMAC и вшивает его.
    Для разработки возвращаем заглушку 'DEV_MODE'.
    """
    # Ищем файл-маркер рядом с exe
    marker = os.path.join(os.path.dirname(_get_exe_path()), ".fluxion_sig")
    if os.path.exists(marker):
        try:
            with open(marker, "r") as f:
                return f.read().strip()
        except:
            pass
    # В PyInstaller можно вшить через --add-data или через переменную окружения при билде
    embedded = os.environ.get("FLUXION_BUILD_SIG", "DEV_MODE")
    return embedded

def verify_integrity() -> tuple[bool, str]:
    """
    Проверяет подлинность файла.
    Возвращает (ok: bool, reason: str)
    """
    embedded = _get_embedded_hmac()

    # Режим разработки — пропускаем
    if embedded == "DEV_MODE":
        return True, "dev_mode"

    actual = _compute_file_hmac(_get_exe_path())
    if not actual:
        return False, "Не удалось прочитать файл программы"

    if not hmac.compare_digest(embedded, actual):
        return False, "Файл повреждён или модифицирован"

    return True, "ok"

# ──────────────────────────────────────────────────────────────
#  ОНЛАЙН ВЕРИФИКАЦИЯ (опциональная)
# ──────────────────────────────────────────────────────────────

def _machine_id() -> str:
    """Анонимный ID устройства (не привязан к личности)"""
    raw = platform.node() + platform.machine() + str(os.getpid())
    return hashlib.sha256(raw.encode()).hexdigest()[:16]

def verify_online(timeout: int = 5) -> tuple[bool, str]:
    """
    Проверяет через API Fluxion Team что версия не заблокирована.
    Возвращает (ok, reason). При недоступности сети — пропускает.
    """
    try:
        payload = json.dumps({
            "version": "1.0",
            "mid": _machine_id(),
        }).encode()

        req = urllib.request.Request(
            VERIFY_URL,
            data=payload,
            headers={"Content-Type": "application/json",
                     "User-Agent": "AnimeFlash/1.0 FluxionTeam"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            if data.get("blocked"):
                return False, data.get("reason", "Версия заблокирована")
            return True, "ok"
    except Exception:
        # Нет сети — не блокируем, просто пропускаем
        return True, "offline"

# ──────────────────────────────────────────────────────────────
#  EULA ПРИНЯТО?
# ──────────────────────────────────────────────────────────────

def _eula_accepted() -> bool:
    try:
        os.makedirs(os.path.dirname(EULA_ACCEPTED_FILE), exist_ok=True)
        if not os.path.exists(EULA_ACCEPTED_FILE):
            return False
        with open(EULA_ACCEPTED_FILE, "r") as f:
            data = json.load(f)
        return data.get("version") == EULA_VERSION and data.get("accepted") is True
    except:
        return False

def _save_eula_accepted():
    try:
        os.makedirs(os.path.dirname(EULA_ACCEPTED_FILE), exist_ok=True)
        with open(EULA_ACCEPTED_FILE, "w") as f:
            json.dump({
                "accepted": True,
                "version":  EULA_VERSION,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "mid": _machine_id(),
            }, f, indent=2)
    except:
        pass

# ──────────────────────────────────────────────────────────────
#  ОКНО — ПИРАТСКАЯ КОПИЯ
# ──────────────────────────────────────────────────────────────

class PiracyBlockWindow(tk.Tk):
    """Показывается если файл не прошёл проверку подписи"""
    def __init__(self, reason: str):
        super().__init__()
        self.title("⛔ AnimeFlash — Ошибка подлинности")
        self.geometry("560x400")
        self.resizable(False, False)
        self.configure(bg=C["bg"])
        self.result = False
        self._build(reason)

    def _build(self, reason: str):
        # Анимированный фон — красные частицы
        tk.Label(self, text="⛔", font=("Segoe UI", 60),
                 fg=C["danger"], bg=C["bg"]).pack(pady=(30, 5))

        tk.Label(self,
                 text="НЕПОДЛИННАЯ КОПИЯ",
                 font=("Segoe UI", 18, "bold"),
                 fg=C["danger"], bg=C["bg"]).pack()

        tk.Label(self,
                 text="Fluxion Team",
                 font=("Segoe UI", 11),
                 fg=C["accent2"], bg=C["bg"]).pack()

        tk.Frame(self, bg=C["border"], height=1).pack(fill="x", padx=30, pady=15)

        msg = (
            f"Эта копия AnimeFlash не является официальной.\n\n"
            f"Причина: {reason}\n\n"
            f"Пиратские копии могут содержать:\n"
            f"  • Вирусы и трояны\n"
            f"  • Майнеры криптовалюты\n"
            f"  • Стилеры паролей\n\n"
            f"Скачайте оригинал:"
        )
        tk.Label(self, text=msg,
                 font=("Segoe UI", 10),
                 fg=C["text"], bg=C["bg"],
                 justify="left").pack(padx=30, anchor="w")

        link = tk.Label(self,
                        text=f"🌐 {OFFICIAL_SITE}",
                        font=("Segoe UI", 11, "underline"),
                        fg=C["accent3"], bg=C["bg"],
                        cursor="hand2")
        link.pack(pady=4)
        link.bind("<Button-1>", lambda e: self._open_site())

        btn_frame = tk.Frame(self, bg=C["bg"])
        btn_frame.pack(pady=15)

        tk.Button(btn_frame, text="🌐 Скачать официально",
                  font=("Segoe UI", 10, "bold"),
                  fg="white", bg=C["accent"],
                  relief="flat", padx=16, pady=8,
                  cursor="hand2",
                  command=self._open_site).pack(side="left", padx=8)

        tk.Button(btn_frame, text="✖ Закрыть",
                  font=("Segoe UI", 10),
                  fg=C["text2"], bg=C["card"],
                  relief="flat", padx=16, pady=8,
                  cursor="hand2",
                  command=self.destroy).pack(side="left", padx=8)

    def _open_site(self):
        import webbrowser
        webbrowser.open(OFFICIAL_SITE)

# ──────────────────────────────────────────────────────────────
#  ОКНО — EULA
# ──────────────────────────────────────────────────────────────

class EULAWindow(tk.Toplevel):
    """Красивое окно лицензионного соглашения"""
    def __init__(self, parent):
        super().__init__(parent)
        self.title("🌸 Лицензионное соглашение — Fluxion Team")
        self.geometry("700x560")
        self.resizable(True, True)
        self.configure(bg=C["bg"])
        self.grab_set()             # модальное окно
        self.result = False         # True = принято
        self._scroll_end = False
        self._build()
        self.wait_window()          # блокируем до закрытия

    def _build(self):
        # ── Заголовок ──
        header = tk.Frame(self, bg=C["bg2"], pady=14)
        header.pack(fill="x")

        tk.Label(header, text="🌸 Fluxion Team",
                 font=("Segoe UI", 18, "bold"),
                 fg=C["accent"], bg=C["bg2"]).pack()
        tk.Label(header, text="Лицензионное соглашение конечного пользователя",
                 font=("Segoe UI", 10),
                 fg=C["text2"], bg=C["bg2"]).pack()

        tk.Frame(self, bg=C["border"], height=1).pack(fill="x")

        # ── Текст EULA с прокруткой ──
        text_frame = tk.Frame(self, bg=C["bg"])
        text_frame.pack(fill="both", expand=True, padx=16, pady=10)

        scrollbar = tk.Scrollbar(text_frame)
        scrollbar.pack(side="right", fill="y")

        self._text = tk.Text(
            text_frame,
            yscrollcommand=scrollbar.set,
            bg=C["card"], fg=C["text"],
            font=("Consolas", 9),
            relief="flat",
            wrap="word",
            padx=14, pady=10,
            state="normal",
            cursor="arrow",
        )
        self._text.pack(fill="both", expand=True)
        scrollbar.config(command=self._text.yview)

        # Теги для окраски
        self._text.tag_config("title",   foreground=C["accent"],  font=("Consolas", 10, "bold"))
        self._text.tag_config("section", foreground=C["accent2"], font=("Consolas", 9, "bold"))
        self._text.tag_config("ok",      foreground=C["success"])
        self._text.tag_config("bad",     foreground=C["danger"])
        self._text.tag_config("warn",    foreground=C["warning"])
        self._text.tag_config("link",    foreground=C["accent3"],  underline=True)
        self._text.tag_config("center",  justify="center")

        self._render_eula()
        self._text.config(state="disabled")

        # Следим за прокруткой
        self._text.bind("<KeyRelease>", self._check_scroll)
        self._text.bind("<ButtonRelease>", self._check_scroll)
        scrollbar.config(command=self._on_scroll)

        # ── Нижняя панель ──
        bottom = tk.Frame(self, bg=C["bg2"], pady=12)
        bottom.pack(fill="x")

        self._scroll_hint = tk.Label(
            bottom,
            text="⬇️  Прокрутите до конца, чтобы принять",
            font=("Segoe UI", 9, "italic"),
            fg=C["warning"], bg=C["bg2"]
        )
        self._scroll_hint.pack(pady=(0, 6))

        btn_frame = tk.Frame(bottom, bg=C["bg2"])
        btn_frame.pack()

        self._accept_btn = tk.Button(
            btn_frame,
            text="✅  Принять соглашение",
            font=("Segoe UI", 11, "bold"),
            fg="white", bg=C["accent"],
            relief="flat", padx=20, pady=10,
            cursor="hand2",
            state="disabled",          # включится после прокрутки
            command=self._accept,
        )
        self._accept_btn.pack(side="left", padx=10)

        tk.Button(
            btn_frame,
            text="❌  Отказаться и выйти",
            font=("Segoe UI", 10),
            fg=C["text2"], bg=C["card"],
            relief="flat", padx=14, pady=10,
            cursor="hand2",
            command=self._decline,
        ).pack(side="left", padx=10)

        tk.Label(bottom,
                 text=f"© 2025 Fluxion Team  •  {OFFICIAL_SITE}",
                 font=("Segoe UI", 8),
                 fg=C["text2"], bg=C["bg2"]).pack(pady=(6, 0))

    def _render_eula(self):
        """Вставляет текст EULA с подсветкой"""
        lines = EULA_TEXT.split("\n")
        for line in lines:
            if "╔" in line or "╚" in line or "║" in line:
                self._text.insert("end", line + "\n", "title")
            elif line.strip().startswith("━"):
                self._text.insert("end", line + "\n", "section")
            elif line.strip().startswith("✅"):
                self._text.insert("end", line + "\n", "ok")
            elif line.strip().startswith("❌") or "Запрещено" in line:
                self._text.insert("end", line + "\n", "bad")
            elif "https://" in line:
                self._text.insert("end", line + "\n", "link")
            elif any(x in line for x in ["🌸", "1.", "2.", "3.", "4.", "5.", "6.", "7.", "8."]):
                self._text.insert("end", line + "\n", "section")
            elif line.strip().startswith("•"):
                tag = "bad" if any(x in line for x in ["торрент", "Telegram", "варезн"]) else ""
                self._text.insert("end", line + "\n", tag)
            else:
                self._text.insert("end", line + "\n")

    def _on_scroll(self, *args):
        self._text.yview(*args)
        self._check_scroll()

    def _check_scroll(self, event=None):
        """Включает кнопку принять когда дочитал до конца"""
        if self._scroll_end:
            return
        pos = self._text.yview()
        if pos[1] >= 0.98:          # 98% прокручено
            self._scroll_end = True
            self._accept_btn.config(state="normal", bg=C["accent"])
            self._scroll_hint.config(
                text="✅  Можно принять соглашение",
                fg=C["success"]
            )

    def _accept(self):
        self.result = True
        _save_eula_accepted()
        self.destroy()

    def _decline(self):
        self.result = False
        self.destroy()

# ──────────────────────────────────────────────────────────────
#  ГЛАВНАЯ ТОЧКА ВХОДА — вызывается перед запуском AnimeFlash
# ──────────────────────────────────────────────────────────────

class GuardResult:
    def __init__(self, ok: bool, reason: str = ""):
        self.ok = ok
        self.reason = reason

def run_guard(parent_window=None) -> GuardResult:
    """
    Выполняет все проверки:
      1. Целостность файла (анти-пиратство)
      2. Онлайн верификация (не заблокирована ли версия)
      3. EULA (если ещё не принято)

    Возвращает GuardResult(ok=True) если всё в порядке.
    Если нет — показывает соответствующее окно.
    """

    # ── 1. Проверка целостности ──────────────────
    ok, reason = verify_integrity()
    if not ok:
        win = PiracyBlockWindow(reason)
        win.mainloop()
        return GuardResult(False, f"Integrity check failed: {reason}")

    # ── 2. Онлайн проверка (в фоне, не блокирует) ─
    _online_result = {"ok": True, "reason": ""}
    def _check_online():
        ok2, r2 = verify_online(timeout=4)
        _online_result["ok"] = ok2
        _online_result["reason"] = r2
    t = threading.Thread(target=_check_online, daemon=True)
    t.start()

    # ── 3. EULA ──────────────────────────────────
    if not _eula_accepted():
        if parent_window is None:
            # Создаём временное root-окно
            root = tk.Tk()
            root.withdraw()
            eula = EULAWindow(root)
            accepted = eula.result
            root.destroy()
        else:
            eula = EULAWindow(parent_window)
            accepted = eula.result

        if not accepted:
            return GuardResult(False, "EULA not accepted")

    # ── 4. Ждём онлайн результат (макс 5 сек) ────
    t.join(timeout=5)
    if not _online_result["ok"]:
        reason = _online_result["reason"]
        # Показываем предупреждение через messagebox
        if parent_window:
            messagebox.showerror(
                "AnimeFlash — Fluxion Team",
                f"⛔ Версия заблокирована сервером Fluxion Team.\n\n"
                f"Причина: {reason}\n\n"
                f"Скачайте актуальную версию на {OFFICIAL_SITE}",
                parent=parent_window
            )
        return GuardResult(False, f"Online blocked: {reason}")

    return GuardResult(True)

# ──────────────────────────────────────────────────────────────
#  УТИЛИТА ДЛЯ БИЛДА: генерация подписи
# ──────────────────────────────────────────────────────────────

def generate_signature_for_build(filepath: str) -> str:
    """
    Вызывается build.py при сборке .exe.
    Генерирует HMAC-подпись и сохраняет в .fluxion_sig рядом с exe.
    """
    sig = _compute_file_hmac(filepath)
    sig_file = os.path.join(os.path.dirname(filepath), ".fluxion_sig")
    with open(sig_file, "w") as f:
        f.write(sig)
    print(f"[Fluxion Build] Подпись: {sig}")
    print(f"[Fluxion Build] Файл:    {sig_file}")
    return sig


if __name__ == "__main__":
    # Тест модуля
    result = run_guard()
    print(f"Guard result: ok={result.ok}, reason={result.reason}")
