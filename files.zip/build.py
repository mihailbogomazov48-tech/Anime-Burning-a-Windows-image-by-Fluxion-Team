#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════╗
║   AnimeFlash BUILD SCRIPT — Fluxion Team     ║
║   Собирает .exe и вшивает подпись защиты     ║
╚══════════════════════════════════════════════╝

Запуск:  python build.py

Требования:
    pip install pyinstaller
"""

import os
import sys
import subprocess
import shutil
import hashlib
import hmac
import json
import time

BUILD_DIR   = "dist"
SRC_FILE    = "animeflash.py"
EXE_NAME    = "AnimeFlash"
VERSION     = "1.0"
SECRET_KEY  = b"FLUXION_TEAM_SECRET_2025_ANIMEFLASH"

def banner():
    print("""
╔══════════════════════════════════════════════════╗
║       🌸 AnimeFlash Build System v1.0            ║
║              Fluxion Team                        ║
╚══════════════════════════════════════════════════╝
""")

def compute_hmac(filepath: str) -> str:
    h = hmac.new(SECRET_KEY, digestmod=hashlib.sha256)
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def build_exe():
    print("🔨 Сборка .exe через PyInstaller...")
    cmd = [
        "pyinstaller",
        "--onefile",
        "--windowed",
        f"--name={EXE_NAME}",
        "--add-data", "modules;modules",
        "--hidden-import", "tkinter",
        "--hidden-import", "tkinter.ttk",
        "--hidden-import", "json",
        "--hidden-import", "hashlib",
        "--hidden-import", "hmac",
        "--hidden-import", "urllib.request",
        "--distpath", BUILD_DIR,
        "--workpath", "build_tmp",
        "--specpath", "build_tmp",
        SRC_FILE,
    ]
    result = subprocess.run(cmd)
    return result.returncode == 0

def sign_exe():
    exe_path = os.path.join(BUILD_DIR, f"{EXE_NAME}.exe")
    if not os.path.exists(exe_path):
        # Linux/Mac build
        exe_path = os.path.join(BUILD_DIR, EXE_NAME)
    if not os.path.exists(exe_path):
        print(f"❌ Не найден .exe: {exe_path}")
        return False

    print(f"🔐 Подпись файла: {exe_path}")
    sig = compute_hmac(exe_path)
    sig_file = os.path.join(BUILD_DIR, ".fluxion_sig")
    with open(sig_file, "w") as f:
        f.write(sig)

    print(f"✅ Подпись: {sig[:20]}...{sig[-10:]}")
    print(f"✅ Файл подписи: {sig_file}")
    return True

def create_release_info():
    exe_path = os.path.join(BUILD_DIR, f"{EXE_NAME}.exe")
    if not os.path.exists(exe_path):
        exe_path = os.path.join(BUILD_DIR, EXE_NAME)

    size = os.path.getsize(exe_path) if os.path.exists(exe_path) else 0
    info = {
        "name":      "AnimeFlash",
        "version":   VERSION,
        "team":      "Fluxion Team",
        "site":      "https://fluxionteam.ru",
        "built_at":  time.strftime("%Y-%m-%d %H:%M:%S"),
        "size_mb":   round(size / 1024 / 1024, 2),
        "sha256":    compute_hmac(exe_path) if os.path.exists(exe_path) else "",
    }
    with open(os.path.join(BUILD_DIR, "release_info.json"), "w") as f:
        json.dump(info, f, indent=2)
    print(f"📋 Release info: {json.dumps(info, indent=2)}")

def main():
    banner()

    if not shutil.which("pyinstaller"):
        print("❌ PyInstaller не найден!")
        print("   Установи: pip install pyinstaller")
        sys.exit(1)

    # Шаг 1: Сборка
    if not build_exe():
        print("❌ Сборка провалилась!")
        sys.exit(1)
    print("✅ .exe собран!")

    # Шаг 2: Подпись
    if not sign_exe():
        print("⚠️  Подпись не удалась (это не критично для dev)")

    # Шаг 3: Release info
    create_release_info()

    print(f"""
╔══════════════════════════════════════════════╗
║           ✅ СБОРКА ЗАВЕРШЕНА!               ║
║                                              ║
║  Файлы в папке: {BUILD_DIR:<29}║
║  {EXE_NAME}.exe  — основной файл            ║
║  .fluxion_sig  — подпись Fluxion Team       ║
║  release_info.json — информация о сборке    ║
║                                              ║
║  🌸 Fluxion Team — fluxionteam.ru           ║
╚══════════════════════════════════════════════╝
""")

if __name__ == "__main__":
    main()
