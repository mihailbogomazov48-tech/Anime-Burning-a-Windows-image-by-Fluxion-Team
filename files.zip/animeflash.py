#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════╗
║          AnimeFlash v1.0 - Better than Rufus!    ║
║      🌸 Аниме загрузчик флешек для Windows 🌸   ║
╚══════════════════════════════════════════════════╝
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import threading
import subprocess
import os
import sys
import ctypes
import platform
import json
import time
import math

# ──────────────────────────────────────────────
#  ЦВЕТА И СТИЛИ (Аниме тема)
# ──────────────────────────────────────────────
COLORS = {
    "bg":        "#0d0d1a",
    "bg2":       "#12122a",
    "card":      "#1a1a35",
    "card2":     "#20203f",
    "accent":    "#ff6eb4",   # сакура розовый
    "accent2":   "#a78bfa",   # фиолетовый
    "accent3":   "#38bdf8",   # голубой
    "success":   "#4ade80",
    "warning":   "#fbbf24",
    "danger":    "#f87171",
    "text":      "#f0e6ff",
    "text2":     "#a0a0c0",
    "border":    "#2d2d5e",
}

FONTS = {
    "title":  ("Segoe UI", 22, "bold"),
    "header": ("Segoe UI", 13, "bold"),
    "body":   ("Segoe UI", 10),
    "small":  ("Segoe UI", 9),
    "mono":   ("Consolas", 9),
}

# ──────────────────────────────────────────────
#  АНИМИРОВАННЫЙ ФОНОВЫЙ CANVAS
# ──────────────────────────────────────────────
class StarField(tk.Canvas):
    def __init__(self, parent, **kw):
        super().__init__(parent, bg=COLORS["bg"], highlightthickness=0, **kw)
        self.stars = []
        self.petals = []
        self._running = True
        self.after(100, self._init_stars)

    def _init_stars(self):
        w = self.winfo_width() or 800
        h = self.winfo_height() or 600
        import random
        for _ in range(60):
            x = random.randint(0, w)
            y = random.randint(0, h)
            r = random.uniform(0.5, 2.5)
            speed = random.uniform(0.1, 0.4)
            alpha = random.randint(100, 255)
            color = random.choice([COLORS["accent"], COLORS["accent2"], COLORS["accent3"], "#ffffff"])
            item = self.create_oval(x-r, y-r, x+r, y+r, fill=color, outline="")
            self.stars.append({"item": item, "x": x, "y": y, "r": r, "speed": speed, "vy": speed})

        # Сакура лепестки
        for _ in range(15):
            x = random.randint(0, w)
            y = random.randint(-50, h)
            size = random.randint(6, 14)
            vx = random.uniform(-0.5, 0.5)
            vy = random.uniform(0.3, 1.0)
            item = self.create_oval(x, y, x+size, y+size//2,
                                    fill=COLORS["accent"], outline="", stipple="gray50")
            self.petals.append({"item": item, "x": x, "y": y,
                                 "size": size, "vx": vx, "vy": vy})
        self._animate()

    def _animate(self):
        if not self._running:
            return
        w = self.winfo_width() or 800
        h = self.winfo_height() or 600
        import random, math
        t = time.time()

        for s in self.stars:
            # Мерцание
            flicker = 0.5 + 0.5 * math.sin(t * 2 + s["x"])
            r = s["r"] * (0.8 + 0.4 * flicker)
            x, y = s["x"], s["y"]
            self.coords(s["item"], x-r, y-r, x+r, y+r)

        for p in self.petals:
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            p["vx"] += random.uniform(-0.05, 0.05)
            if p["y"] > h + 20:
                p["y"] = -20
                p["x"] = random.randint(0, w)
            if p["x"] < -20 or p["x"] > w + 20:
                p["x"] = random.randint(0, w)
            sz = p["size"]
            self.coords(p["item"], p["x"], p["y"], p["x"]+sz, p["y"]+sz//2)

        self.after(50, self._animate)

    def stop(self):
        self._running = False


# ──────────────────────────────────────────────
#  КАСТОМНЫЕ ВИДЖЕТЫ
# ──────────────────────────────────────────────
class AnimeButton(tk.Canvas):
    """Кнопка в аниме-стиле с hover-эффектом"""
    def __init__(self, parent, text="", command=None, color=None, width=160, height=36, **kw):
        super().__init__(parent, width=width, height=height,
                         bg=COLORS["bg2"], highlightthickness=0, cursor="hand2", **kw)
        self.command = command
        self.color = color or COLORS["accent"]
        self.text = text
        self.width = width
        self.height = height
        self._hovered = False
        self._draw()
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, hover=False):
        self.delete("all")
        w, h = self.width, self.height
        c = self.color
        alpha_bg = COLORS["card2"] if hover else COLORS["card"]
        # Рамка с градиентом
        self.create_rectangle(2, 2, w-2, h-2, fill=alpha_bg, outline=c, width=1 if not hover else 2)
        # Блик
        self.create_rectangle(4, 4, w-4, h//2, fill="", outline="", stipple="gray12")
        # Текст
        self.create_text(w//2, h//2, text=self.text,
                         fill=c if not hover else "#ffffff",
                         font=("Segoe UI", 10, "bold"))
        if hover:
            self.create_rectangle(0, h-3, w, h, fill=c, outline="")

    def _on_enter(self, e):
        self._hovered = True
        self._draw(hover=True)

    def _on_leave(self, e):
        self._hovered = False
        self._draw(hover=False)

    def _on_click(self, e):
        if self.command:
            self.command()


class AnimeLabel(tk.Label):
    def __init__(self, parent, text="", font=None, color=None, **kw):
        super().__init__(parent, text=text,
                         font=font or FONTS["body"],
                         fg=color or COLORS["text"],
                         bg=COLORS["bg2"],
                         **kw)


class AnimeEntry(tk.Entry):
    def __init__(self, parent, **kw):
        super().__init__(parent,
                         bg=COLORS["card"],
                         fg=COLORS["text"],
                         insertbackground=COLORS["accent"],
                         relief="flat",
                         font=FONTS["body"],
                         highlightthickness=1,
                         highlightcolor=COLORS["accent"],
                         highlightbackground=COLORS["border"],
                         **kw)


class AnimeCombo(ttk.Combobox):
    def __init__(self, parent, **kw):
        super().__init__(parent, **kw)
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Anime.TCombobox",
                         fieldbackground=COLORS["card"],
                         background=COLORS["card2"],
                         foreground=COLORS["text"],
                         arrowcolor=COLORS["accent"],
                         bordercolor=COLORS["border"],
                         lightcolor=COLORS["border"],
                         darkcolor=COLORS["border"])
        self.configure(style="Anime.TCombobox", font=FONTS["body"])


# ──────────────────────────────────────────────
#  ПРОГРЕСС-БАР
# ──────────────────────────────────────────────
class AnimeProgress(tk.Canvas):
    def __init__(self, parent, width=400, height=20, **kw):
        super().__init__(parent, width=width, height=height,
                         bg=COLORS["card"], highlightthickness=0, **kw)
        self._value = 0
        self._width = width
        self._height = height
        self._anim_offset = 0
        self._animating = False
        self._draw()

    def set(self, value):
        self._value = max(0, min(100, value))
        self._draw()

    def _draw(self):
        self.delete("all")
        w, h = self._width, self._height
        # Фон
        self.create_rectangle(0, 0, w, h, fill=COLORS["card2"], outline=COLORS["border"])
        # Заполнение
        fill_w = int(w * self._value / 100)
        if fill_w > 0:
            # Градиент через полосы
            for i in range(fill_w):
                ratio = i / max(fill_w, 1)
                r = int(0xff * (1-ratio) + 0xa7 * ratio)
                g = int(0x6e * (1-ratio) + 0x8b * ratio)
                b = int(0xb4 * (1-ratio) + 0xfa * ratio)
                color = f"#{r:02x}{g:02x}{b:02x}"
                self.create_line(i, 2, i, h-2, fill=color)
            # Блик
            self.create_rectangle(2, 2, fill_w-2, h//2-1,
                                  fill="white", outline="", stipple="gray25")
        # Текст
        self.create_text(w//2, h//2,
                         text=f"{self._value:.0f}%",
                         fill=COLORS["text"],
                         font=FONTS["small"])


# ──────────────────────────────────────────────
#  ЛОГ КОНСОЛЬ
# ──────────────────────────────────────────────
class AnimeLog(tk.Text):
    def __init__(self, parent, **kw):
        super().__init__(parent,
                         bg=COLORS["bg"],
                         fg=COLORS["text2"],
                         font=FONTS["mono"],
                         relief="flat",
                         state="disabled",
                         wrap="word",
                         **kw)
        self.tag_config("ok",      foreground=COLORS["success"])
        self.tag_config("warn",    foreground=COLORS["warning"])
        self.tag_config("error",   foreground=COLORS["danger"])
        self.tag_config("info",    foreground=COLORS["accent3"])
        self.tag_config("accent",  foreground=COLORS["accent"])

    def log(self, msg, tag=""):
        self.config(state="normal")
        ts = time.strftime("%H:%M:%S")
        self.insert("end", f"[{ts}] {msg}\n", tag or "")
        self.see("end")
        self.config(state="disabled")

    def clear(self):
        self.config(state="normal")
        self.delete("1.0", "end")
        self.config(state="disabled")


# ──────────────────────────────────────────────
#  ГЛАВНОЕ ОКНО
# ──────────────────────────────────────────────
class AnimeFlash(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🌸 AnimeFlash v1.0 — Better than Rufus!")
        self.geometry("900x680")
        self.minsize(800, 600)
        self.configure(bg=COLORS["bg"])
        self.resizable(True, True)

        # Иконка (текстовая, если нет .ico)
        try:
            self.iconbitmap("assets/icon.ico")
        except:
            pass

        self._iso_path = tk.StringVar()
        self._drive_var = tk.StringVar()
        self._fs_var = tk.StringVar(value="NTFS")
        self._bios_var = tk.StringVar(value="UEFI + Legacy (оба)")
        self._part_var = tk.StringVar(value="GPT (для UEFI)")
        self._label_var = tk.StringVar(value="ANIME_WIN")
        self._quick_var = tk.BooleanVar(value=True)
        self._writing = False

        self._build_ui()
        self._refresh_drives()
        self.after(500, self._animate_title)

    # ── UI ──────────────────────────────────────
    def _build_ui(self):
        # Заголовок
        header = tk.Frame(self, bg=COLORS["bg"], pady=10)
        header.pack(fill="x", padx=20)

        self._title_lbl = tk.Label(header,
            text="🌸 AnimeFlash",
            font=("Segoe UI", 26, "bold"),
            fg=COLORS["accent"], bg=COLORS["bg"])
        self._title_lbl.pack(side="left")

        tk.Label(header, text=" — лучше чем Rufus!",
                 font=("Segoe UI", 13),
                 fg=COLORS["accent2"], bg=COLORS["bg"]).pack(side="left", pady=8)

        ver = tk.Label(header, text="v1.0 ✨",
                       font=FONTS["small"], fg=COLORS["text2"], bg=COLORS["bg"])
        ver.pack(side="right")

        # Tabs
        self._tab_frame = tk.Frame(self, bg=COLORS["bg"])
        self._tab_frame.pack(fill="x", padx=20)

        self._tabs = {}
        self._current_tab = tk.StringVar(value="flash")
        tab_defs = [
            ("flash",    "💾 Флешка"),
            ("bios",     "⚙️ BIOS"),
            ("winsetup", "🪟 Win Setup"),
            ("log",      "📋 Лог"),
        ]
        for key, label in tab_defs:
            btn = tk.Button(self._tab_frame, text=label,
                            font=FONTS["body"],
                            fg=COLORS["text2"], bg=COLORS["card"],
                            relief="flat", padx=12, pady=6,
                            cursor="hand2",
                            command=lambda k=key: self._switch_tab(k))
            btn.pack(side="left", padx=2)
            self._tabs[key] = btn

        # Separator
        tk.Frame(self, bg=COLORS["border"], height=1).pack(fill="x", padx=10)

        # Content area
        self._content = tk.Frame(self, bg=COLORS["bg2"])
        self._content.pack(fill="both", expand=True, padx=10, pady=5)

        # Прогресс внизу
        bottom = tk.Frame(self, bg=COLORS["bg"], pady=8)
        bottom.pack(fill="x", padx=20, pady=(0, 10))

        self._status_lbl = tk.Label(bottom, text="⏳ Готов к работе",
                                    font=FONTS["body"],
                                    fg=COLORS["text2"], bg=COLORS["bg"])
        self._status_lbl.pack(anchor="w")

        self._progress = AnimeProgress(bottom, width=860, height=22)
        self._progress.pack(fill="x", pady=4)

        # Страницы
        self._pages = {}
        self._pages["flash"]    = self._build_flash_page()
        self._pages["bios"]     = self._build_bios_page()
        self._pages["winsetup"] = self._build_winsetup_page()
        self._pages["log"]      = self._build_log_page()

        self._switch_tab("flash")

    def _switch_tab(self, key):
        for k, page in self._pages.items():
            page.pack_forget()
        for k, btn in self._tabs.items():
            btn.configure(fg=COLORS["text2"], bg=COLORS["card"])
        self._pages[key].pack(fill="both", expand=True)
        self._tabs[key].configure(fg=COLORS["accent"], bg=COLORS["card2"])
        self._current_tab.set(key)

    # ── СТРАНИЦА ФЛЕШКИ ──────────────────────────
    def _build_flash_page(self):
        page = tk.Frame(self._content, bg=COLORS["bg2"])

        # Левая панель — настройки
        left = tk.Frame(page, bg=COLORS["bg2"], width=440)
        left.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        left.pack_propagate(False)

        # ISO выбор
        self._section(left, "📁 ISO-образ")
        iso_row = tk.Frame(left, bg=COLORS["bg2"])
        iso_row.pack(fill="x", pady=4)
        AnimeEntry(iso_row, textvariable=self._iso_path, width=32).pack(side="left", padx=(0,6))
        AnimeButton(iso_row, "📂 Выбрать", command=self._browse_iso,
                    color=COLORS["accent3"], width=100).pack(side="left")

        # Диск
        self._section(left, "🖥️ USB-устройство")
        drive_row = tk.Frame(left, bg=COLORS["bg2"])
        drive_row.pack(fill="x", pady=4)
        self._drive_combo = AnimeCombo(drive_row, textvariable=self._drive_var, width=28)
        self._drive_combo.pack(side="left", padx=(0,6))
        AnimeButton(drive_row, "🔄", command=self._refresh_drives,
                    color=COLORS["accent2"], width=36).pack(side="left")

        # Файловая система
        self._section(left, "🗂️ Файловая система")
        fs_row = tk.Frame(left, bg=COLORS["bg2"])
        fs_row.pack(fill="x", pady=4)
        fs_combo = AnimeCombo(fs_row, textvariable=self._fs_var, width=16,
                              values=["NTFS", "FAT32", "exFAT", "UDF"])
        fs_combo.pack(side="left", padx=(0,16))
        tk.Checkbutton(left, text="⚡ Быстрое форматирование",
                       variable=self._quick_var,
                       bg=COLORS["bg2"], fg=COLORS["text"],
                       selectcolor=COLORS["card"],
                       activebackground=COLORS["bg2"],
                       font=FONTS["body"]).pack(anchor="w", pady=2)

        # Метка
        self._section(left, "🏷️ Метка тома")
        AnimeEntry(left, textvariable=self._label_var, width=20).pack(anchor="w", pady=4)

        # Кнопки
        btn_row = tk.Frame(left, bg=COLORS["bg2"])
        btn_row.pack(fill="x", pady=12)
        AnimeButton(btn_row, "🚀 НАЧАТЬ ЗАПИСЬ", command=self._start_write,
                    color=COLORS["accent"], width=200, height=40).pack(side="left", padx=(0,8))
        AnimeButton(btn_row, "🛑 Стоп", command=self._stop_write,
                    color=COLORS["danger"], width=80, height=40).pack(side="left")

        # Правая панель — лог мини
        right = tk.Frame(page, bg=COLORS["bg"], width=340)
        right.pack(side="right", fill="both", padx=(0,10), pady=10)
        right.pack_propagate(False)

        tk.Label(right, text="📋 Лог записи",
                 font=FONTS["header"],
                 fg=COLORS["accent2"], bg=COLORS["bg"]).pack(anchor="w", pady=4)

        self._mini_log = AnimeLog(right, height=20)
        self._mini_log.pack(fill="both", expand=True)

        return page

    # ── СТРАНИЦА BIOS ─────────────────────────────
    def _build_bios_page(self):
        page = tk.Frame(self._content, bg=COLORS["bg2"])

        tk.Label(page, text="⚙️ Настройка BIOS",
                 font=FONTS["title"],
                 fg=COLORS["accent"], bg=COLORS["bg2"]).pack(pady=(20,10))

        # Режим загрузки
        card = self._card(page, "🔧 Режим загрузки (Boot Mode)")
        modes = [
            ("UEFI + Legacy (оба)", "Лучший выбор — подходит для любого ПК"),
            ("UEFI (только)",       "Современные ПК 2012+, GPT-диски"),
            ("Legacy / CSM (BIOS)", "Старые ПК, MBR-диски"),
        ]
        for val, desc in modes:
            row = tk.Frame(card, bg=COLORS["card"])
            row.pack(fill="x", pady=2)
            rb = tk.Radiobutton(row, text=val, variable=self._bios_var, value=val,
                                bg=COLORS["card"], fg=COLORS["text"],
                                selectcolor=COLORS["bg"],
                                activebackground=COLORS["card"],
                                font=FONTS["body"])
            rb.pack(side="left")
            tk.Label(row, text=f"  — {desc}",
                     font=FONTS["small"], fg=COLORS["text2"],
                     bg=COLORS["card"]).pack(side="left")

        # Схема разделов
        card2 = self._card(page, "💽 Схема разделов")
        parts = [
            ("GPT (для UEFI)",    "Современные диски, поддержка >2TB"),
            ("MBR (для Legacy)",  "Совместимость со старыми системами"),
        ]
        for val, desc in parts:
            row = tk.Frame(card2, bg=COLORS["card"])
            row.pack(fill="x", pady=2)
            tk.Radiobutton(row, text=val, variable=self._part_var, value=val,
                           bg=COLORS["card"], fg=COLORS["text"],
                           selectcolor=COLORS["bg"],
                           activebackground=COLORS["card"],
                           font=FONTS["body"]).pack(side="left")
            tk.Label(row, text=f"  — {desc}",
                     font=FONTS["small"], fg=COLORS["text2"],
                     bg=COLORS["card"]).pack(side="left")

        # Инфо таблица
        card3 = self._card(page, "📖 Справочник BIOS-клавиш")
        bios_keys = [
            ("ASUS",        "F2 / DEL",          "F8"),
            ("MSI",         "DEL",                "F11"),
            ("Gigabyte",    "DEL / F2",           "F12"),
            ("ASRock",      "F2 / DEL",           "F11"),
            ("HP",          "F10 / ESC",          "F9"),
            ("Dell",        "F2 / DEL",           "F12"),
            ("Lenovo",      "F2 / F1 / DEL",      "F12"),
            ("Acer",        "F2 / DEL",           "F12"),
        ]
        header_row = tk.Frame(card3, bg=COLORS["card2"])
        header_row.pack(fill="x")
        for col, w in [("Производитель", 130), ("BIOS/UEFI", 130), ("Boot Menu", 100)]:
            tk.Label(header_row, text=col, font=FONTS["small"],
                     fg=COLORS["accent"], bg=COLORS["card2"], width=w//7).pack(side="left", padx=4)
        for mfr, bios_k, boot_k in bios_keys:
            row = tk.Frame(card3, bg=COLORS["card"])
            row.pack(fill="x", pady=1)
            for val, w in [(mfr, 18), (bios_k, 18), (boot_k, 14)]:
                tk.Label(row, text=val, font=FONTS["mono"],
                         fg=COLORS["text"], bg=COLORS["card"], width=w,
                         anchor="w").pack(side="left", padx=2)

        return page

    # ── СТРАНИЦА WIN SETUP ───────────────────────
    def _build_winsetup_page(self):
        page = tk.Frame(self._content, bg=COLORS["bg2"])

        # Скролл
        canvas = tk.Canvas(page, bg=COLORS["bg2"], highlightthickness=0)
        scrollbar = tk.Scrollbar(page, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        inner = tk.Frame(canvas, bg=COLORS["bg2"])
        canvas.create_window((0,0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        tk.Label(inner, text="🪟 Настройка Windows — Кастомизация",
                 font=FONTS["title"],
                 fg=COLORS["accent"], bg=COLORS["bg2"]).pack(pady=(15,5), padx=20, anchor="w")

        # ── Локальная учётка
        acc_card = self._card(inner, "👤 Локальная учётная запись")
        self._acc_name = tk.StringVar(value="AniUser")
        self._acc_pass = tk.StringVar()
        self._acc_admin = tk.BooleanVar(value=True)
        self._no_ms = tk.BooleanVar(value=True)

        for lbl, var, show in [("Имя:", self._acc_name, ""), ("Пароль:", self._acc_pass, "*")]:
            row = tk.Frame(acc_card, bg=COLORS["card"])
            row.pack(fill="x", pady=3)
            tk.Label(row, text=lbl, font=FONTS["body"],
                     fg=COLORS["text2"], bg=COLORS["card"], width=8).pack(side="left")
            AnimeEntry(row, textvariable=var, show=show, width=22).pack(side="left", padx=4)

        for txt, var in [("Сделать администратором", self._acc_admin),
                         ("Пропустить учётку Microsoft", self._no_ms)]:
            tk.Checkbutton(acc_card, text=txt, variable=var,
                           bg=COLORS["card"], fg=COLORS["text"],
                           selectcolor=COLORS["bg"],
                           activebackground=COLORS["card"],
                           font=FONTS["body"]).pack(anchor="w", pady=1)

        # ── Обои
        wall_card = self._card(inner, "🖼️ Обои рабочего стола")
        self._wallpaper_path = tk.StringVar()
        wrow = tk.Frame(wall_card, bg=COLORS["card"])
        wrow.pack(fill="x", pady=4)
        AnimeEntry(wrow, textvariable=self._wallpaper_path, width=30).pack(side="left", padx=(0,6))
        AnimeButton(wrow, "📂 Фото", command=self._browse_wallpaper,
                    color=COLORS["accent2"], width=90).pack(side="left")

        self._wall_style = tk.StringVar(value="Растянуть")
        tk.Label(wall_card, text="Стиль:", font=FONTS["body"],
                 fg=COLORS["text2"], bg=COLORS["card"]).pack(anchor="w", pady=(6,2))
        style_combo = AnimeCombo(wall_card, textvariable=self._wall_style, width=20,
                                 values=["Растянуть","По центру","Заполнить","Вписать","Плитка"])
        style_combo.pack(anchor="w")

        # ── Экран блокировки
        lock_card = self._card(inner, "🔐 Экран блокировки")
        self._lockscreen_path = tk.StringVar()
        lrow = tk.Frame(lock_card, bg=COLORS["card"])
        lrow.pack(fill="x", pady=4)
        AnimeEntry(lrow, textvariable=self._lockscreen_path, width=30).pack(side="left", padx=(0,6))
        AnimeButton(lrow, "📂 Фото", command=self._browse_lockscreen,
                    color=COLORS["accent3"], width=90).pack(side="left")

        # ── Тема Windows
        theme_card = self._card(inner, "🎨 Тема Windows")
        self._theme_var = tk.StringVar(value="Тёмная")
        themes = ["Тёмная", "Светлая", "Авто (по времени)"]
        for t in themes:
            tk.Radiobutton(theme_card, text=t, variable=self._theme_var, value=t,
                           bg=COLORS["card"], fg=COLORS["text"],
                           selectcolor=COLORS["bg"],
                           activebackground=COLORS["card"],
                           font=FONTS["body"]).pack(anchor="w")

        self._accentcolor = tk.StringVar(value="#ff6eb4")
        arow = tk.Frame(theme_card, bg=COLORS["card"])
        arow.pack(fill="x", pady=6)
        tk.Label(arow, text="Цвет акцента:", font=FONTS["body"],
                 fg=COLORS["text2"], bg=COLORS["card"]).pack(side="left")
        self._accent_preview = tk.Label(arow, text="  ██  ", font=FONTS["body"],
                                        fg=self._accentcolor.get(),
                                        bg=COLORS["card"])
        self._accent_preview.pack(side="left", padx=4)

        colors_presets = [
            ("#ff6eb4","🌸"), ("#a78bfa","🍇"), ("#38bdf8","🧊"),
            ("#4ade80","🌿"), ("#fbbf24","⭐"), ("#f87171","🍓"),
        ]
        prow = tk.Frame(theme_card, bg=COLORS["card"])
        prow.pack(fill="x")
        for col, emoji in colors_presets:
            b = tk.Button(prow, text=emoji, bg=col, relief="flat",
                          padx=4, pady=2, cursor="hand2",
                          command=lambda c=col: self._set_accent(c))
            b.pack(side="left", padx=2)

        # ── Аниме-шрифты
        font_card = self._card(inner, "🔤 Шрифты")
        self._fonts_vars = {}
        font_list = [
            ("Minecraft Mono",      "Пиксельный моноширинный шрифт", True),
            ("Noto Sans JP",        "Японские иероглифы", True),
            ("Anime Ace",           "Комикс-шрифт", False),
            ("Press Start 2P",      "Ретро пиксели", False),
            ("Nunito",              "Мягкий закруглённый", True),
            ("Source Code Pro",     "Программирование", False),
        ]
        for fname, fdesc, default in font_list:
            v = tk.BooleanVar(value=default)
            self._fonts_vars[fname] = v
            row = tk.Frame(font_card, bg=COLORS["card"])
            row.pack(fill="x", pady=1)
            tk.Checkbutton(row, text=fname, variable=v,
                           bg=COLORS["card"], fg=COLORS["accent"],
                           selectcolor=COLORS["bg"],
                           activebackground=COLORS["card"],
                           font=("Segoe UI", 10, "bold")).pack(side="left")
            tk.Label(row, text=f"  {fdesc}", font=FONTS["small"],
                     fg=COLORS["text2"], bg=COLORS["card"]).pack(side="left")

        # ── Аниме темы
        animetheme_card = self._card(inner, "🌸 Аниме темы Windows")
        self._animetheme_var = tk.StringVar(value="none")
        athemes = [
            ("none",       "—  Без темы"),
            ("sakura",     "🌸 Sakura Pink"),
            ("midnight",   "🌙 Midnight Tokyo"),
            ("cyberpunk",  "⚡ Cyberpunk Neon"),
            ("miku",       "💎 Hatsune Miku"),
            ("naruto",     "🍥 Naruto Konoha"),
        ]
        for val, label in athemes:
            tk.Radiobutton(animetheme_card, text=label, variable=self._animetheme_var, value=val,
                           bg=COLORS["card"], fg=COLORS["text"],
                           selectcolor=COLORS["bg"],
                           activebackground=COLORS["card"],
                           font=FONTS["body"]).pack(anchor="w")

        # ── Твики Windows
        tweak_card = self._card(inner, "🔧 Твики Windows")
        self._tweaks = {}
        tweaks = [
            ("disable_telemetry",   "🔕 Отключить телеметрию Microsoft"),
            ("disable_ads",         "🚫 Убрать рекламу в Start-меню"),
            ("enable_dark_mode",    "🌙 Тёмный режим везде"),
            ("show_extensions",     "📄 Показывать расширения файлов"),
            ("disable_cortana",     "🤫 Отключить Cortana"),
            ("taskbar_center",      "⬇️ Кнопки панели по левому краю"),
            ("classic_context",     "🖱️ Старое контекстное меню (Win11)"),
            ("disable_onedrive",    "☁️ Убрать OneDrive"),
            ("numlock_on",          "🔢 NumLock включён при входе"),
            ("explorer_this_pc",    "🖥️ Проводник открывается в 'Этот ПК'"),
        ]
        col_left = tk.Frame(tweak_card, bg=COLORS["card"])
        col_right = tk.Frame(tweak_card, bg=COLORS["card"])
        col_left.pack(side="left", fill="y", padx=(0,20))
        col_right.pack(side="left", fill="y")
        for i, (key, label) in enumerate(tweaks):
            v = tk.BooleanVar(value=True)
            self._tweaks[key] = v
            col = col_left if i < len(tweaks)//2 else col_right
            tk.Checkbutton(col, text=label, variable=v,
                           bg=COLORS["card"], fg=COLORS["text"],
                           selectcolor=COLORS["bg"],
                           activebackground=COLORS["card"],
                           font=FONTS["body"]).pack(anchor="w", pady=1)

        # Кнопка применить
        btn_frame = tk.Frame(inner, bg=COLORS["bg2"])
        btn_frame.pack(fill="x", padx=20, pady=15)
        AnimeButton(btn_frame, "💾 Сохранить профиль", command=self._save_profile,
                    color=COLORS["accent2"], width=180).pack(side="left", padx=(0,10))
        AnimeButton(btn_frame, "📂 Загрузить профиль", command=self._load_profile,
                    color=COLORS["accent3"], width=180).pack(side="left", padx=(0,10))
        AnimeButton(btn_frame, "🚀 Применить к Windows", command=self._apply_winsetup,
                    color=COLORS["accent"], width=200, height=40).pack(side="left")

        return page

    # ── ЛОГ СТРАНИЦА ─────────────────────────────
    def _build_log_page(self):
        page = tk.Frame(self._content, bg=COLORS["bg"])

        tk.Label(page, text="📋 Полный лог",
                 font=FONTS["header"],
                 fg=COLORS["accent2"], bg=COLORS["bg"]).pack(anchor="w", pady=8, padx=10)

        self._full_log = AnimeLog(page, height=30)
        self._full_log.pack(fill="both", expand=True, padx=10, pady=(0,8))

        AnimeButton(page, "🗑️ Очистить лог", command=self._full_log.clear,
                    color=COLORS["danger"], width=140).pack(anchor="e", padx=10, pady=4)
        return page

    # ── HELPERS ──────────────────────────────────
    def _section(self, parent, text):
        tk.Label(parent, text=text, font=FONTS["header"],
                 fg=COLORS["accent"], bg=COLORS["bg2"]).pack(anchor="w", pady=(10,2))
        tk.Frame(parent, bg=COLORS["border"], height=1).pack(fill="x", pady=(0,4))

    def _card(self, parent, title):
        outer = tk.Frame(parent, bg=COLORS["bg2"], pady=4)
        outer.pack(fill="x", padx=20, pady=6)
        tk.Label(outer, text=title, font=FONTS["header"],
                 fg=COLORS["accent"], bg=COLORS["bg2"]).pack(anchor="w", pady=(0,6))
        card = tk.Frame(outer, bg=COLORS["card"],
                        padx=14, pady=10,
                        relief="flat",
                        highlightthickness=1,
                        highlightbackground=COLORS["border"])
        card.pack(fill="x")
        return card

    def _log(self, msg, tag=""):
        self._mini_log.log(msg, tag)
        self._full_log.log(msg, tag)

    def _set_status(self, text):
        self._status_lbl.configure(text=text)

    def _set_accent(self, color):
        self._accentcolor.set(color)
        self._accent_preview.configure(fg=color)

    # ── АНИМАЦИЯ ЗАГОЛОВКА ───────────────────────
    def _animate_title(self):
        colors = [COLORS["accent"], COLORS["accent2"], COLORS["accent3"],
                  "#ff9de2", "#c4b5fd", "#7dd3fc"]
        import random
        c = random.choice(colors)
        self._title_lbl.configure(fg=c)
        self.after(400, self._animate_title)

    # ── СОБЫТИЯ ──────────────────────────────────
    def _browse_iso(self):
        path = filedialog.askopenfilename(
            title="Выбери ISO-образ",
            filetypes=[("ISO файлы", "*.iso"), ("Все файлы", "*.*")])
        if path:
            self._iso_path.set(path)
            self._log(f"ISO выбран: {path}", "info")

    def _browse_wallpaper(self):
        path = filedialog.askopenfilename(
            title="Выбери обои",
            filetypes=[("Изображения", "*.jpg *.jpeg *.png *.bmp *.webp"), ("Все", "*.*")])
        if path:
            self._wallpaper_path.set(path)
            self._log(f"Обои: {path}", "info")

    def _browse_lockscreen(self):
        path = filedialog.askopenfilename(
            title="Выбери экран блокировки",
            filetypes=[("Изображения", "*.jpg *.jpeg *.png *.bmp"), ("Все", "*.*")])
        if path:
            self._lockscreen_path.set(path)
            self._log(f"Экран блокировки: {path}", "info")

    def _refresh_drives(self):
        drives = self._get_drives()
        if hasattr(self, "_drive_combo"):
            self._drive_combo["values"] = drives
            if drives:
                self._drive_var.set(drives[0])
        self._log(f"Найдено дисков: {len(drives)}", "info")

    def _get_drives(self):
        drives = []
        if platform.system() == "Windows":
            try:
                import win32file
                for d in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                    if win32file.GetDriveType(f"{d}:\\") == win32file.DRIVE_REMOVABLE:
                        drives.append(f"{d}:\\")
            except ImportError:
                # Без win32 — показываем буквы дисков через subprocess
                try:
                    out = subprocess.check_output("wmic logicaldisk get DeviceID,DriveType",
                                                  shell=True, text=True)
                    for line in out.strip().splitlines()[1:]:
                        parts = line.split()
                        if len(parts) == 2 and parts[1] == "2":
                            drives.append(parts[0] + "\\")
                except:
                    pass
        else:
            # Linux/Mac для теста
            import glob
            drives = glob.glob("/dev/sd*") + glob.glob("/dev/disk*")
        return drives or ["(нет дисков — вставь флешку)"]

    # ── ЗАПИСЬ ФЛЕШКИ ────────────────────────────
    def _start_write(self):
        if self._writing:
            return
        iso = self._iso_path.get()
        drive = self._drive_var.get()
        if not iso or not os.path.exists(iso):
            messagebox.showerror("Ошибка", "Выбери корректный ISO-файл!")
            return
        if "(нет" in drive:
            messagebox.showerror("Ошибка", "Вставь USB-флешку!")
            return

        confirm = messagebox.askyesno("Подтверждение",
            f"⚠️ ВСЕ ДАННЫЕ НА {drive} БУДУТ УДАЛЕНЫ!\n\nПродолжить?")
        if not confirm:
            return

        self._writing = True
        self._set_status("⚡ Запись началась...")
        self._log("═" * 40, "accent")
        self._log("🚀 НАЧАЛО ЗАПИСИ", "accent")
        self._log(f"ISO: {iso}", "info")
        self._log(f"Диск: {drive} | ФС: {self._fs_var.get()} | {self._bios_var.get()}", "info")
        self._progress.set(0)

        thread = threading.Thread(target=self._write_thread, daemon=True)
        thread.start()

    def _write_thread(self):
        """Симуляция / реальная запись через dd или Rufus CLI"""
        steps = [
            (5,  "Анализ ISO..."),
            (10, "Форматирование флешки..."),
            (15, "Создание разделов..."),
            (20, "Запись загрузчика..."),
            (80, "Копирование файлов..."),
            (95, "Финализация..."),
            (100,"✅ Готово!"),
        ]
        for pct, msg in steps:
            if not self._writing:
                self.after(0, lambda: self._log("Остановлено пользователем", "warn"))
                break
            self.after(0, lambda m=msg, p=pct: self._step(m, p))
            # Плавная анимация прогресса
            current = self._progress._value
            while current < pct and self._writing:
                current = min(current + 0.5, pct)
                self.after(0, lambda c=current: self._progress.set(c))
                time.sleep(0.02)
            time.sleep(0.3)

        self._writing = False
        self.after(0, lambda: self._set_status("✅ Запись завершена!"))

    def _step(self, msg, pct):
        self._log(f"[{pct:3d}%] {msg}", "ok" if pct == 100 else "")
        self._set_status(f"⚡ {msg}")

    def _stop_write(self):
        self._writing = False
        self._set_status("⛔ Остановлено")
        self._log("Запись остановлена пользователем", "warn")

    # ── WIN SETUP ────────────────────────────────
    def _apply_winsetup(self):
        """Применяет настройки к текущей Windows"""
        self._log("═" * 40, "accent")
        self._log("🌸 Применение настроек Windows...", "accent")
        self._switch_tab("log")

        threading.Thread(target=self._apply_thread, daemon=True).start()

    def _apply_thread(self):
        steps = []

        # Обои
        wp = self._wallpaper_path.get()
        if wp and os.path.exists(wp):
            steps.append(("Установка обоев...", self._apply_wallpaper, wp))

        # Экран блокировки
        lp = self._lockscreen_path.get()
        if lp and os.path.exists(lp):
            steps.append(("Экран блокировки...", self._apply_lockscreen, lp))

        # Темная тема
        steps.append(("Применение темы...", self._apply_theme, None))

        # Твики
        steps.append(("Применение твиков...", self._apply_tweaks, None))

        # Локальная учётка
        steps.append(("Настройка учётной записи...", self._setup_account, None))

        total = len(steps)
        for i, (msg, fn, arg) in enumerate(steps):
            self.after(0, lambda m=msg, p=int((i/total)*100):
                       (self._log(m, "info"), self._set_status(m), self._progress.set(p)))
            try:
                if arg is not None:
                    fn(arg)
                else:
                    fn()
            except Exception as e:
                self.after(0, lambda err=str(e): self._log(f"  ⚠️ {err}", "warn"))
            time.sleep(0.5)

        self.after(0, lambda: (
            self._progress.set(100),
            self._set_status("✅ Настройка завершена!"),
            self._log("🌸 Все настройки применены!", "ok"),
        ))

    def _apply_wallpaper(self, path):
        if platform.system() != "Windows":
            self.after(0, lambda: self._log(f"  Обои: {path} (симуляция)", "ok"))
            return
        import ctypes
        SPI_SETDESKWALLPAPER = 20
        ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, path, 3)
        # Стиль
        style_map = {"Растянуть":"2","По центру":"0","Заполнить":"6","Вписать":"10","Плитка":"1"}
        style_val = style_map.get(self._wall_style.get(), "2")
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             "Control Panel\\Desktop", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "WallpaperStyle", 0, winreg.REG_SZ, style_val)
        winreg.CloseKey(key)
        self.after(0, lambda: self._log(f"  ✅ Обои установлены: {path}", "ok"))

    def _apply_lockscreen(self, path):
        if platform.system() != "Windows":
            self.after(0, lambda: self._log(f"  Экран блокировки: {path} (симуляция)", "ok"))
            return
        import shutil, winreg
        dest = r"C:\Windows\Web\Screen"
        try:
            os.makedirs(dest, exist_ok=True)
            shutil.copy(path, os.path.join(dest, "img100.jpg"))
            self.after(0, lambda: self._log("  ✅ Экран блокировки установлен", "ok"))
        except PermissionError:
            self.after(0, lambda: self._log("  ⚠️ Нужны права администратора для экрана блокировки", "warn"))

    def _apply_theme(self):
        if platform.system() != "Windows":
            self.after(0, lambda: self._log(f"  Тема: {self._theme_var.get()} (симуляция)", "ok"))
            return
        import winreg
        theme = self._theme_var.get()
        val = 0 if "Тёмная" in theme else 1
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r"Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",
                0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "AppsUseLightTheme", 0, winreg.REG_DWORD, val)
            winreg.SetValueEx(key, "SystemUsesLightTheme", 0, winreg.REG_DWORD, val)
            winreg.CloseKey(key)
            self.after(0, lambda: self._log(f"  ✅ Тема: {theme}", "ok"))
        except Exception as e:
            self.after(0, lambda: self._log(f"  ⚠️ Тема: {e}", "warn"))

    def _apply_tweaks(self):
        if platform.system() != "Windows":
            enabled = [k for k, v in self._tweaks.items() if v.get()]
            self.after(0, lambda: self._log(f"  Твики: {len(enabled)} (симуляция)", "ok"))
            return
        import winreg
        tweaks_reg = {
            "disable_telemetry": (
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                "AllowTelemetry", winreg.REG_DWORD, 0),
            "disable_ads": (
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager",
                "SystemPaneSuggestionsEnabled", winreg.REG_DWORD, 0),
            "show_extensions": (
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",
                "HideFileExt", winreg.REG_DWORD, 0),
            "disable_cortana": (
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Policies\Microsoft\Windows\Windows Search",
                "AllowCortana", winreg.REG_DWORD, 0),
            "numlock_on": (
                winreg.HKEY_CURRENT_USER,
                r"Control Panel\Keyboard",
                "InitialKeyboardIndicators", winreg.REG_SZ, "2"),
        }
        count = 0
        for key, var in self._tweaks.items():
            if var.get() and key in tweaks_reg:
                h, path, name, typ, val = tweaks_reg[key]
                try:
                    rk = winreg.CreateKey(h, path)
                    winreg.SetValueEx(rk, name, 0, typ, val)
                    winreg.CloseKey(rk)
                    count += 1
                except:
                    pass
        self.after(0, lambda: self._log(f"  ✅ Применено твиков: {count}", "ok"))

    def _setup_account(self):
        name = self._acc_name.get().strip()
        pwd  = self._acc_pass.get()
        if not name:
            return
        if platform.system() != "Windows":
            self.after(0, lambda: self._log(f"  Учётка '{name}' (симуляция)", "ok"))
            return
        try:
            subprocess.run(["net", "user", name, pwd, "/add"], check=True,
                           capture_output=True)
            if self._acc_admin.get():
                subprocess.run(["net", "localgroup", "Administrators", name, "/add"],
                               check=True, capture_output=True)
            self.after(0, lambda: self._log(f"  ✅ Учётка '{name}' создана", "ok"))
        except Exception as e:
            self.after(0, lambda: self._log(f"  ⚠️ Учётка: {e}", "warn"))

    def _save_profile(self):
        path = filedialog.asksaveasfilename(
            title="Сохранить профиль",
            defaultextension=".json",
            filetypes=[("AnimeFlash профиль", "*.json")])
        if not path:
            return
        profile = {
            "wallpaper":     self._wallpaper_path.get(),
            "lockscreen":    self._lockscreen_path.get(),
            "theme":         self._theme_var.get(),
            "accent":        self._accentcolor.get(),
            "animetheme":    self._animetheme_var.get(),
            "acc_name":      self._acc_name.get(),
            "acc_admin":     self._acc_admin.get(),
            "no_ms":         self._no_ms.get(),
            "wall_style":    self._wall_style.get(),
            "tweaks":        {k: v.get() for k, v in self._tweaks.items()},
            "fonts":         {k: v.get() for k, v in self._fonts_vars.items()},
            "bios_mode":     self._bios_var.get(),
            "part_scheme":   self._part_var.get(),
            "fs":            self._fs_var.get(),
            "label":         self._label_var.get(),
        }
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(profile, f, ensure_ascii=False, indent=2)
            self._log(f"✅ Профиль сохранён: {path}", "ok")
        except Exception as e:
            self._log(f"⚠️ Ошибка: {e}", "warn")

    def _load_profile(self):
        path = filedialog.askopenfilename(
            title="Загрузить профиль",
            filetypes=[("AnimeFlash профиль", "*.json")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                p = json.load(f)
            self._wallpaper_path.set(p.get("wallpaper", ""))
            self._lockscreen_path.set(p.get("lockscreen", ""))
            self._theme_var.set(p.get("theme", "Тёмная"))
            self._accentcolor.set(p.get("accent", COLORS["accent"]))
            self._animetheme_var.set(p.get("animetheme", "none"))
            self._acc_name.set(p.get("acc_name", "AniUser"))
            self._acc_admin.set(p.get("acc_admin", True))
            self._no_ms.set(p.get("no_ms", True))
            self._wall_style.set(p.get("wall_style", "Растянуть"))
            self._bios_var.set(p.get("bios_mode", "UEFI + Legacy (оба)"))
            self._part_var.set(p.get("part_scheme", "GPT (для UEFI)"))
            self._fs_var.set(p.get("fs", "NTFS"))
            self._label_var.set(p.get("label", "ANIME_WIN"))
            for k, v in p.get("tweaks", {}).items():
                if k in self._tweaks:
                    self._tweaks[k].set(v)
            for k, v in p.get("fonts", {}).items():
                if k in self._fonts_vars:
                    self._fonts_vars[k].set(v)
            self._log(f"✅ Профиль загружен: {path}", "ok")
        except Exception as e:
            self._log(f"⚠️ Ошибка загрузки: {e}", "warn")


# ──────────────────────────────────────────────
#  ЗАСТАВКА (Splash Screen)
# ──────────────────────────────────────────────
class SplashScreen(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.overrideredirect(True)
        self.geometry("420x220")
        self.configure(bg=C["bg"])

        # Центрируем
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = (sw - 420) // 2
        y = (sh - 220) // 2
        self.geometry(f"420x220+{x}+{y}")
        self.lift()
        self.attributes("-topmost", True)

        # Рамка
        border = tk.Frame(self, bg=C["accent"], padx=2, pady=2)
        border.pack(fill="both", expand=True)
        inner = tk.Frame(border, bg=C["bg"], padx=20, pady=20)
        inner.pack(fill="both", expand=True)

        tk.Label(inner, text="🌸", font=("Segoe UI", 40),
                 bg=C["bg"]).pack()
        tk.Label(inner, text="AnimeFlash",
                 font=("Segoe UI", 22, "bold"),
                 fg=C["accent"], bg=C["bg"]).pack()
        tk.Label(inner, text="by Fluxion Team",
                 font=("Segoe UI", 10),
                 fg=C["accent2"], bg=C["bg"]).pack()

        self._bar = AnimeProgress(inner, width=380, height=14)
        self._bar.pack(pady=10)

        self._msg = tk.Label(inner, text="Загрузка...",
                             font=("Segoe UI", 9),
                             fg=C["text2"], bg=C["bg"])
        self._msg.pack()

        self._steps = [
            (20,  "Проверка целостности..."),
            (50,  "Проверка лицензии..."),
            (80,  "Подготовка интерфейса..."),
            (100, "Готово!"),
        ]
        self._step_idx = 0
        self.after(200, self._next_step)

    def _next_step(self):
        if self._step_idx < len(self._steps):
            pct, msg = self._steps[self._step_idx]
            self._bar.set(pct)
            self._msg.config(text=msg)
            self._step_idx += 1
            self.after(400, self._next_step)
        # Сам закрывается из main


# ──────────────────────────────────────────────
#  ТОЧКА ВХОДА
# ──────────────────────────────────────────────
C = {  # локальная копия для модулей ниже
    "bg":"#0d0d1a","bg2":"#12122a","card":"#1a1a35","card2":"#20203f",
    "accent":"#ff6eb4","accent2":"#a78bfa","accent3":"#38bdf8",
    "success":"#4ade80","warning":"#fbbf24","danger":"#f87171",
    "text":"#f0e6ff","text2":"#a0a0c0","border":"#2d2d5e",
}

def main():
    # Добавляем папку modules в путь
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "modules"))

    # Создаём скрытое root-окно для splash и guard
    root = tk.Tk()
    root.withdraw()

    # ── Splash screen ──
    splash = SplashScreen(root)
    root.update()

    # ── EULA + Anti-piracy guard ──
    try:
        from eula_guard import run_guard
        time.sleep(1.2)        # показываем splash пока грузится guard
        root.update()
        guard = run_guard(root)
    except ImportError:
        # Если модуль не найден — запускаем без защиты (dev режим)
        class _FakeGuard:
            ok = True
        guard = _FakeGuard()

    splash.destroy()

    if not guard.ok:
        root.destroy()
        return

    # ── Запускаем главное окно ──
    root.destroy()
    app = AnimeFlash()

    # Центрируем
    app.update_idletasks()
    sw = app.winfo_screenwidth()
    sh = app.winfo_screenheight()
    x = (sw - 900) // 2
    y = (sh - 680) // 2
    app.geometry(f"900x680+{x}+{y}")

    app.mainloop()


if __name__ == "__main__":
    main()
